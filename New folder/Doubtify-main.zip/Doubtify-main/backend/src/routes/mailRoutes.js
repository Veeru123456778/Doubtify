// import { sendMail } from "../controllers/sendMailController";
// import express from 'express';
// const mailRouter = express.Router()

// mailRouter.get('/sendMail',sendMail);

// export default mailRouter;