import React from "react";
import Signin from "../components/Signin";

function SignIn() {
  return  <Signin />;
}

export default SignIn;
