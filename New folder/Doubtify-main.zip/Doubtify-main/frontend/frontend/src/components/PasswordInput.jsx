import React, { useState } from 'react';

const PasswordInput = ({ value, onChange }) => {
    const [showPassword, setShowPassword] = useState(false);

    return (
        <div>
            <input
                type={showPassword ? 'text' : 'password'}
                value={value}
                onChange={onChange}
                className="form-input w-full text-gray-300"
                placeholder="Password (at least 10 characters)"
                required
            />
            <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="mt-2 text-sm text-blue-500"
            >
                {showPassword ? 'Hide' : 'Show'}
            </button>
        </div>
    );
};

export default PasswordInput;
