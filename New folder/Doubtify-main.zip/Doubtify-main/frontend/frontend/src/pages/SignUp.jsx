import React from "react";
import Signup from "../components/Signup";

function SignUp() {
  return <Signup />;
}

export default SignUp;
